package com.ornek.sirenana;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class ActionReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String cmd = "STOP".equals(intent.getAction()) ? "STOP" : "START";
        PendingResult result = goAsync();
        new Thread(() -> {
            try { Wire.send(context.getApplicationContext(), cmd); }
            catch (Exception e) { android.util.Log.e("SirenAna", "Komut gönderilemedi", e); }
            finally { result.finish(); }
        }, "siren-send").start();
    }
}
