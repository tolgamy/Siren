package com.ornek.sirenana;

import android.Manifest;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.graphics.Color;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.google.mlkit.vision.codescanner.GmsBarcodeScanner;
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;

/** Controller: opens a real Google Code Scanner UI, not the stock camera. */
public class MainActivity extends Activity {
    private static final String CHANNEL = "ana_kumanda";
    private EditText entry;
    private TextView status;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        ScrollView scroll = new ScrollView(this);
        LinearLayout layout = new LinearLayout(this);
        layout.setPadding(32, 36, 32, 28);
        layout.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(layout);
        text(layout, "ANA TELEFON — SİREN KUMANDASI", 21);
        text(layout, "Kullanıcı telefonundaki QR kodunu okut. İki telefonun da interneti açık olmalı.", 15);
        button(layout, "▣ QR KOD OKUT", this::scanQr);
        entry = new EditText(this);
        entry.setSingleLine(true);
        entry.setHint("QR çalışmazsa 32 haneli kodu gir");
        entry.setText(Wire.code(this));
        layout.addView(entry);
        button(layout, "EŞLEŞME KODUNU KAYDET", this::saveManual);
        button(layout, "🔊 SİREN ÇALDIR", () -> send("START"));
        button(layout, "■ SİRENİ DURDUR", () -> send("STOP"));
        button(layout, "BİLDİRİM PANELİNE KUMANDA EKLE", this::showControls);
        status = text(layout, Wire.valid(Wire.code(this)) ? "Eşleşme kayıtlı; dinleme açık olmalı." : "Önce QR kod okut.", 16);
        setContentView(scroll);
        askNotificationPermission();
    }
    private void scanQr() {
        status.setText("QR tarayıcı açılıyor...");
        try {
            GmsBarcodeScannerOptions options = new GmsBarcodeScannerOptions.Builder()
                .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
                .enableAutoZoom()
                .build();
            GmsBarcodeScanner scanner = GmsBarcodeScanning.getClient(this, options);
            scanner.startScan()
                .addOnSuccessListener(barcode -> {
                    String code = Pairing.fromQr(barcode.getRawValue());
                    if (code == null) {
                        status.setText("Bu QR, Siren Kullanıcı eşleşme kodu değil.");
                        return;
                    }
                    Wire.save(this, code);
                    entry.setText(code);
                    status.setText("QR ile eşleşme kaydedildi. Kullanıcı telefonunda DİNLEMEYİ AÇ düğmesine bas.");
                })
                .addOnCanceledListener(() -> status.setText("QR okuma iptal edildi."))
                .addOnFailureListener(ex -> status.setText("QR okuyucu açılamadı: " + ex.getMessage() + " — kodu elle de girebilirsin."));
        } catch (Exception | LinkageError e) {
            status.setText("QR tarayıcı kullanılamıyor: " + e.getMessage() + " — kodu elle girebilirsin.");
        }
    }
    private void saveManual() {
        String code = Wire.normalize(entry.getText().toString());
        if (!Pairing.valid(code)) {
            status.setText("Kod 32 adet 0-9 / a-f karakterinden oluşmalıdır.");
            return;
        }
        Wire.save(this, code);
        status.setText("Eşleşme kodu kaydedildi.");
    }
    private void send(String cmd) {
        status.setText("Komut internet üzerinden gönderiliyor...");
        new Thread(() -> {
            try {
                Wire.send(getApplicationContext(), cmd);
                runOnUiThread(() -> status.setText(cmd.equals("START")
                    ? "Siren komutu sunucuya gönderildi (alıcıdan çalma onayı değil)."
                    : "Durdurma komutu sunucuya gönderildi."));
            } catch (Exception e) {
                runOnUiThread(() -> status.setText("Komut gönderilemedi: " + e.getMessage()));
            }
        }, "siren-send").start();
    }
    private void askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 42);
        }
    }
    private void showControls() {
        if (!Pairing.valid(Wire.code(this))) {
            status.setText("Önce QR ile eşleştir."); return;
        }
        askNotificationPermission();
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Siren kumandası", NotificationManager.IMPORTANCE_DEFAULT));
        PendingIntent fire = PendingIntent.getBroadcast(this, 0, new Intent(this, ActionReceiver.class).setAction("START"), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stop = PendingIntent.getBroadcast(this, 1, new Intent(this, ActionReceiver.class).setAction("STOP"), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification notice = new Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("Siren Kumandası")
            .setContentText("Komut göndermek için aşağıdaki düğmeye basın")
            .setOngoing(true)
            .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_play, "SİREN ÇALDIR", fire).build())
            .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_pause, "DURDUR", stop).build())
            .build();
        nm.notify(400, notice);
        status.setText("Kumanda bildirimi eklendi.");
    }
    private TextView text(LinearLayout l, String value, int size) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(Color.BLACK); t.setPadding(0, 12, 0, 12); l.addView(t); return t;
    }
    private void button(LinearLayout l, String label, Runnable click) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setOnClickListener(v -> click.run()); l.addView(b);
    }
}
