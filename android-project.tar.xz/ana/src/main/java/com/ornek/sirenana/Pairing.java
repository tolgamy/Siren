package com.ornek.sirenana;

import java.util.Locale;
import java.util.regex.Pattern;

/** Wire format shared with receiver, no Android APIs. */
public final class Pairing {
    private static final Pattern KEY = Pattern.compile("[0-9a-f]{32}");
    private Pairing() {}
    public static String normalize(String raw) {
        if (raw == null) return "";
        return raw.trim().toLowerCase(Locale.ROOT).replace("-", "").replace(" ", "");
    }
    public static boolean valid(String key) { return KEY.matcher(normalize(key)).matches(); }
    public static String fromQr(String value) {
        if (value == null || !value.startsWith("SIREN1:")) return null;
        String code = value.substring("SIREN1:".length());
        // QR values must use exact 32-char canonical form; avoid accepting arbitrary input.
        return KEY.matcher(code).matches() ? code : null;
    }
}
