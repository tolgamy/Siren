package com.ornek.sirenana;

import android.content.Context;
import android.content.SharedPreferences;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.regex.Pattern;

final class Wire {
    private Wire() { }
    static final String PREF = "siren_ana";
    private static final Pattern CODE = Pattern.compile("[0-9a-f]{32}");
    static String normalize(String code) { return code.trim().toLowerCase(Locale.US).replace("-", "").replace(" ", ""); }
    static boolean valid(String code) { return CODE.matcher(normalize(code)).matches(); }
    static SharedPreferences prefs(Context ctx) { return ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE); }
    static String code(Context ctx) { return prefs(ctx).getString("code", ""); }
    static void save(Context ctx, String code) { prefs(ctx).edit().putString("code", normalize(code)).apply(); }
    static void send(Context ctx, String command) throws Exception {
        String code = code(ctx);
        if (!valid(code)) throw new IllegalStateException("Önce 32 haneli eşleşme kodunu kaydedin.");
        if (!command.equals("START") && !command.equals("STOP")) throw new IllegalArgumentException("Bilinmeyen komut");
        HttpURLConnection conn = (HttpURLConnection) new URL("https://ntfy.sh/uzs-" + code).openConnection();
        try {
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(12000);
            conn.setReadTimeout(12000);
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "text/plain; charset=utf-8");
            conn.setRequestProperty("X-Cache", "no");
            conn.setRequestProperty("X-Priority", "5");
            try (OutputStream output = conn.getOutputStream()) {
                output.write(("UZS1:" + command).getBytes(StandardCharsets.UTF_8));
            }
            if (conn.getResponseCode() / 100 != 2) {
                throw new IllegalStateException("Sunucu hatası: " + conn.getResponseCode());
            }
        } finally { conn.disconnect(); }
    }
}
