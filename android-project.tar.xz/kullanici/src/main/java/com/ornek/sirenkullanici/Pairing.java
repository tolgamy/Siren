package com.ornek.sirenkullanici;

import java.util.regex.Pattern;

/** Wire format shared with controller, no Android APIs. */
public final class Pairing {
    private static final Pattern KEY = Pattern.compile("[0-9a-f]{32}");
    private Pairing() {}
    public static boolean valid(String key) { return key != null && KEY.matcher(key).matches(); }
    public static String toQr(String key) {
        if (!valid(key)) throw new IllegalArgumentException("Invalid pairing key");
        return "SIREN1:" + key;
    }
}
