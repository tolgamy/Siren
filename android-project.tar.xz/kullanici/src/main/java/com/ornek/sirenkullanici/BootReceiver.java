package com.ornek.sirenkullanici;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;
public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;
        if (!Wire.prefs(context).getBoolean("active", false)) return;
        try { context.startForegroundService(new Intent(context, ListenerService.class)); }
        catch (Exception e) { Log.w("SirenKullanici", "Telefon açılışında hizmet başlayamadı; uygulamayı açın", e); }
    }
}
