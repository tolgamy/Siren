package com.ornek.sirenkullanici;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;
import java.util.HashMap;
import java.util.Map;

/** Receiver: displays its own QR; user must explicitly enable listening. */
public class MainActivity extends Activity {
    private TextView status;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView scroll = new ScrollView(this);
        LinearLayout area = new LinearLayout(this);
        area.setPadding(30, 32, 30, 26);
        area.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(area);
        addText(area, "KULLANICI TELEFONU — SİREN ALICISI", 21);
        addText(area, "Ana telefonun QR KOD OKUT düğmesiyle aşağıdaki kodu okut. Sonra dinlemeyi aç.", 15);
        String key = Wire.getCode(this);
        addText(area, "EŞLEŞME QR KODUN", 18);
        ImageView qrImage = new ImageView(this);
        qrImage.setAdjustViewBounds(true);
        qrImage.setContentDescription("Ana telefonun okutacağı siren eşleştirme QR kodu");
        try { qrImage.setImageBitmap(qrBitmap(Pairing.toQr(key), 768)); }
        catch (Exception e) { addText(area, "QR oluşturulamadı: " + e.getMessage(), 14); }
        area.addView(qrImage, new LinearLayout.LayoutParams(-1, -2));
        TextView code = addText(area, "Kod: " + key, 13);
        code.setTextIsSelectable(true);
        button(area, "KODU KOPYALA", () -> {
            ClipboardManager cb = (ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
            cb.setPrimaryClip(ClipData.newPlainText("Siren eşleşme anahtarı", key));
            status.setText("Kod kopyalandı.");
        });
        button(area, "DİNLEMEYİ AÇ", this::startListening);
        button(area, "DİNLEMEYİ KAPAT", this::stopListening);
        button(area, "BU TELEFONDA SİRENİ TEST ET", () -> {
            SirenSound.start(this); status.setText("30 saniyelik test başladı. Alarm ses seviyesi sıfır olmamalı.");
        });
        button(area, "SİRENİ DURDUR", () -> {
            SirenSound.stop(); status.setText("Siren durduruldu.");
        });
        button(area, "ANA EKRAN SİMGESİNİ GİZLE", () -> changeIcon(false));
        button(area, "SİMGEYİ GERİ GETİR", () -> changeIcon(true));
        addText(area, "Simge gizlense bile dinleme hizmetinin bildirimi ve Ayarlar > Uygulamalar kaydı görünür. Bildirime dokunarak uygulamayı açabilirsin. Dinleme kapanırsa simge geri gelir.", 14);
        status = addText(area, "Durum: " + (Wire.prefs(this).getBoolean("active", false) ? "Dinleme seçili" : "Dinleme kapalı"), 16);
        setContentView(scroll);
        askNotifications();
    }
    private static Bitmap qrBitmap(String data, int size) throws Exception {
        Map<EncodeHintType, Object> hints = new HashMap<>();
        hints.put(EncodeHintType.MARGIN, 2);
        BitMatrix matrix = new MultiFormatWriter().encode(data, BarcodeFormat.QR_CODE, size, size, hints);
        Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        int[] pixels = new int[size * size];
        for (int y = 0; y < size; y++) {
            for (int x = 0; x < size; x++) pixels[y * size + x] = matrix.get(x, y) ? Color.BLACK : Color.WHITE;
        }
        bitmap.setPixels(pixels, 0, size, 0, 0, size, size);
        return bitmap;
    }
    private void askNotifications() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 42);
    }
    private void startListening() {
        askNotifications();
        Wire.prefs(this).edit().putBoolean("active", true).apply();
        try {
            Intent intent = new Intent(this, ListenerService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent);
            else startService(intent);
            status.setText("Dinleme başlatılması istendi. Bildirimde 'Uzaktan Siren etkin' görünmeli.");
        } catch (Exception ex) {
            Wire.prefs(this).edit().putBoolean("active", false).apply();
            status.setText("Dinleme başlatılamadı: " + ex.getMessage());
        }
    }
    private void stopListening() {
        Wire.prefs(this).edit().putBoolean("active", false).apply();
        changeIcon(true);
        stopService(new Intent(this, ListenerService.class));
        SirenSound.stop();
        status.setText("Dinleme kapatıldı.");
    }
    private void changeIcon(boolean show) {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (!show && (!Wire.prefs(this).getBoolean("active", false) || !nm.areNotificationsEnabled())) {
            status.setText("Simgeyi gizlemek için dinleme açık ve hizmet bildirimi etkin olmalıdır.");
            return;
        }
        ComponentName alias = new ComponentName(this, "com.ornek.sirenkullanici.LauncherAlias");
        try {
            getPackageManager().setComponentEnabledSetting(alias,
                show ? PackageManager.COMPONENT_ENABLED_STATE_ENABLED : PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP);
            status.setText(show ? "Simge geri geldi." : "Simge gizlendi, hizmet bildirimi görünür kalır.");
        } catch (Exception e) { status.setText("Simge ayarı değiştirilemedi: " + e.getMessage()); }
    }
    private TextView addText(LinearLayout l, String value, int size) {
        TextView t = new TextView(this); t.setText(value); t.setTextColor(Color.BLACK); t.setTextSize(size);
        t.setPadding(0, 12, 0, 12); l.addView(t); return t;
    }
    private void button(LinearLayout l, String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false);
        b.setOnClickListener(v -> action.run()); l.addView(b);
    }
}
