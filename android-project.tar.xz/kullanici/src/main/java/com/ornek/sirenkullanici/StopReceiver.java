package com.ornek.sirenkullanici;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.ComponentName;
import android.content.pm.PackageManager;
public class StopReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String action = intent == null ? ListenerService.ACTION_STOP_SIREN : intent.getAction();
        if (ListenerService.ACTION_STOP_LISTENING.equals(action)) {
            Wire.prefs(context).edit().putBoolean("active", false).apply();
            ComponentName alias = new ComponentName(context, "com.ornek.sirenkullanici.LauncherAlias");
            context.getPackageManager().setComponentEnabledSetting(alias,
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
            context.stopService(new Intent(context, ListenerService.class));
            SirenSound.stop();
        } else { SirenSound.stop(); }
    }
}
