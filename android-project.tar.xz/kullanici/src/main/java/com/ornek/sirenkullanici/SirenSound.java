package com.ornek.sirenkullanici;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.os.PowerManager;
import android.os.SystemClock;
import android.content.Context;
import java.util.concurrent.atomic.AtomicInteger;

final class SirenSound {
    private SirenSound() { }
    private static final AtomicInteger generation = new AtomicInteger();
    private static Thread thread;
    static synchronized void start(Context ctx) {
        stop();
        int myGeneration = generation.get();
        Context app = ctx.getApplicationContext();
        thread = new Thread(() -> runAudio(app, myGeneration), "remote-siren-audio");
        thread.start();
    }
    static synchronized void stop() {
        generation.incrementAndGet();
        if (thread != null) thread.interrupt();
        thread = null;
    }
    private static void runAudio(Context ctx, int myGeneration) {
        AudioTrack track = null;
        PowerManager.WakeLock wl = null;
        try {
            PowerManager pm = (PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "UzaktanSiren:Alarm30s");
            wl.acquire(34000);
            int rate = 22050;
            int bufferSize = Math.max(4096, AudioTrack.getMinBufferSize(rate,
                AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT));
            track = new AudioTrack.Builder()
                .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                .setAudioFormat(new AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(bufferSize).setTransferMode(AudioTrack.MODE_STREAM).build();
            if (track.getState() != AudioTrack.STATE_INITIALIZED) return;
            track.play();
            short[] pcm = new short[1024];
            double phase = 0;
            long begin = SystemClock.elapsedRealtime();
            while (generation.get() == myGeneration && !Thread.currentThread().isInterrupted() && SystemClock.elapsedRealtime() - begin < 30000) {
                long elapsed = SystemClock.elapsedRealtime() - begin;
                double swing = (elapsed / 800.0) % 2.0;
                double frequency = 620.0 + 530.0 * (swing < 1.0 ? swing : 2.0 - swing);
                for (int i = 0; i < pcm.length; i++) {
                    phase += 2.0 * Math.PI * frequency / rate;
                    pcm[i] = (short) (Math.sin(phase) * 18000);
                }
                if (track.write(pcm, 0, pcm.length) < 0) break;
            }
        } catch (Exception e) { android.util.Log.e("SirenKullanici", "Ses hatası", e); }
        finally {
            if (track != null) {
                try { track.pause(); track.flush(); track.release(); } catch (Exception ignored) { }
            }
            if (wl != null && wl.isHeld()) wl.release();
        }
    }
}
