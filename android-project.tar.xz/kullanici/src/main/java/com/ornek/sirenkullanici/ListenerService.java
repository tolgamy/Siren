package com.ornek.sirenkullanici;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.os.SystemClock;
import android.util.Log;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class ListenerService extends Service {
    static final String ACTION_STOP_LISTENING = "stop-listening";
    static final String ACTION_STOP_SIREN = "stop-siren";
    private static final int NOTICE_ID = 41;
    private volatile boolean running = false;
    private volatile HttpURLConnection connection;
    private Thread worker;
    private volatile String lastId;
    private volatile long startedAt;

    @Override public void onCreate() {
        super.onCreate();
        startedAt = System.currentTimeMillis() / 1000;
        makeChannel();
    }
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? "" : intent.getAction();
        if (ACTION_STOP_LISTENING.equals(action)) {
            Wire.prefs(this).edit().putBoolean("active", false).apply();
            showLauncher(true);
            SirenSound.stop();
            stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_STOP_SIREN.equals(action)) { SirenSound.stop(); return START_STICKY; }
        if (!Wire.prefs(this).getBoolean("active", false)) { stopSelf(); return START_NOT_STICKY; }
        Notification notice = makeNotification();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTICE_ID, notice, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else { startForeground(NOTICE_ID, notice); }
        if (!running) {
            running = true;
            worker = new Thread(this::listen, "siren-listener");
            worker.start();
        }
        return START_STICKY;
    }
    void makeChannel() {
        NotificationChannel channel = new NotificationChannel("listener", "Siren dinleme hizmeti", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("Yetki verilmiş uzaktan siren komutları dinleniyor");
        getSystemService(NotificationManager.class).createNotificationChannel(channel);
    }
    Notification makeNotification() {
        Intent activity = new Intent(this, MainActivity.class);
        PendingIntent open = PendingIntent.getActivity(this, 0, activity, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stop = PendingIntent.getBroadcast(this, 0, new Intent(this, StopReceiver.class).setAction(ACTION_STOP_SIREN), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent turnOff = PendingIntent.getBroadcast(this, 1, new Intent(this, StopReceiver.class).setAction(ACTION_STOP_LISTENING), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, "listener")
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("Uzaktan Siren etkin")
            .setContentText("Siren komutları dinleniyor • Ayarlamak için dokunun")
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_pause, "SİRENİ DURDUR", stop).build())
            .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "DİNLEMEYİ KAPAT", turnOff).build())
            .build();
    }
    private void listen() {
        while (running) {
            HttpURLConnection c = null;
            try {
                String since = lastId != null ? lastId : Long.toString(startedAt - 2);
                URL url = new URL(Wire.topic(this) + "/json?since=" + since);
                c = (HttpURLConnection) url.openConnection();
                connection = c;
                c.setConnectTimeout(15000);
                c.setReadTimeout(70000);
                c.setRequestProperty("Accept", "application/x-ndjson");
                if (c.getResponseCode() != 200) throw new IllegalStateException("Sunucu: " + c.getResponseCode());
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8))) {
                    String line;
                    while (running && (line = reader.readLine()) != null) {
                        try { onLine(line); } catch (Exception e) { Log.w("SirenKullanici", "Komut çözümlenemedi", e); }
                    }
                }
            } catch (Exception e) { if (running) Log.w("SirenKullanici", "Bağlantı yeniden denenecek", e); }
            finally { if (c != null) c.disconnect(); connection = null; }
            if (running) SystemClock.sleep(2500);
        }
    }
    private void onLine(String line) throws Exception {
        JSONObject msg = new JSONObject(line);
        if (!"message".equals(msg.optString("event"))) return;
        String id = msg.optString("id");
        if (id.equals(lastId)) return;
        if (!id.isEmpty()) lastId = id;
        long sentAt = msg.optLong("time", 0);
        long now = System.currentTimeMillis() / 1000;
        // Reject old cached commands after reconnection or device reboot.
        if (sentAt < startedAt - 3 || sentAt < now - 120 || sentAt > now + 120) return;
        String command = msg.optString("message");
        if ("UZS1:START".equals(command)) SirenSound.start(this);
        else if ("UZS1:STOP".equals(command)) SirenSound.stop();
    }
    private void showLauncher(boolean show) {
        ComponentName alias = new ComponentName(this, "com.ornek.sirenkullanici.LauncherAlias");
        getPackageManager().setComponentEnabledSetting(alias, show ?
            PackageManager.COMPONENT_ENABLED_STATE_ENABLED : PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            PackageManager.DONT_KILL_APP);
    }
    @Override public void onDestroy() {
        running = false;
        HttpURLConnection c = connection;
        if (c != null) c.disconnect();
        if (worker != null) worker.interrupt();
        SirenSound.stop();
        showLauncher(true);
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
