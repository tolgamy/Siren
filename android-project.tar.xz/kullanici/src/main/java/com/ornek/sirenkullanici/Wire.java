package com.ornek.sirenkullanici;

import android.content.Context;
import android.content.SharedPreferences;
import java.security.SecureRandom;

final class Wire {
    private Wire() { }
    static SharedPreferences prefs(Context ctx) { return ctx.getSharedPreferences("siren_kullanici", Context.MODE_PRIVATE); }
    static String getCode(Context ctx) {
        String old = prefs(ctx).getString("code", null);
        if (old != null) return old;
        byte[] b = new byte[16]; new SecureRandom().nextBytes(b);
        StringBuilder value = new StringBuilder(32);
        char[] hex = "0123456789abcdef".toCharArray();
        for (byte n : b) { value.append(hex[(n >>> 4) & 15]).append(hex[n & 15]); }
        String code = value.toString();
        prefs(ctx).edit().putString("code", code).commit();
        return code;
    }
    static String topic(Context ctx) { return "https://ntfy.sh/uzs-" + getCode(ctx); }
}
