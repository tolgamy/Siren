#!/usr/bin/env bash
set -euo pipefail
if ! command -v gradle >/dev/null 2>&1; then
  echo 'Gradle 8.9 kurulu değil. Android Studio veya GitHub Actions üzerinden derleyin.' >&2
  exit 1
fi
gradle :ana:assembleDebug :kullanici:assembleDebug
printf '\nANA: ana/build/outputs/apk/debug/ana-debug.apk\nKULLANICI: kullanici/build/outputs/apk/debug/kullanici-debug.apk\n'
