#!/bin/sh
set -eu
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TESTDIR="$(mktemp -d)"
trap 'rm -rf "$TESTDIR"' EXIT
javac -encoding UTF-8 -d "$TESTDIR" "$ROOT/ana/src/main/java/com/ornek/sirenana/Pairing.java" "$ROOT/kullanici/src/main/java/com/ornek/sirenkullanici/Pairing.java" "$ROOT/tests/TestPairing.java"
java -cp "$TESTDIR" TestPairing
