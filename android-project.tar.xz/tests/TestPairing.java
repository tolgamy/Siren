import com.ornek.sirenana.Pairing;

public class TestPairing {
    public static void main(String[] args) {
        String code = "0123456789abcdef0123456789abcdef";
        String qr = com.ornek.sirenkullanici.Pairing.toQr(code);
        if (!"SIREN1:0123456789abcdef0123456789abcdef".equals(qr)) throw new AssertionError("Alıcı QR biçimi bozuk");
        if (!Pairing.valid(code) || !code.equals(Pairing.fromQr(qr))) throw new AssertionError("İki uygulama arasında QR eşleşme çözümlenemedi");
        if (Pairing.fromQr("SIREN1:deadbeef") != null) throw new AssertionError("Geçersiz QR kabul edildi");
        if (Pairing.fromQr("https://example.invalid/?key=" + code) != null) throw new AssertionError("Başka QR kabul edildi");
        if (Pairing.valid("z".repeat(32))) throw new AssertionError("Geçersiz kod kabul edildi");
        System.out.println("İki uygulamanın QR eşleştirme protokolü testleri geçti.");
    }
}
