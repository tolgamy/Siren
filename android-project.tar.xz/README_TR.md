# Uzaktan Siren QR — iki Android uygulaması

**Bu paket kaynak projedir, APK içermez.** Önceki elde hazırlanmış APK'lar yerine gerçek Android Gradle derlemesi yapmak için düzenlenmiştir. Bu çalışma ortamında Android SDK/Gradle, dış ağ erişimi veya telefon/emülatör olmadığı için APK derlemesi ve cihaz testi yapılmadı. Çalışma garantisi verilmez.

## Uygulamalar

- **Ana / `ana` modülü:** Gerçek Google Play Hizmetleri QR tarama ekranı (Google Code Scanner), elle kod girme yedeği, SİREN ÇALDIR / SİRENİ DURDUR ve bildirim panelinden kumanda.
- **Kullanıcı / `kullanici` modülü:** Her cihazda SecureRandom ile üretilen 128 bit eşleşme anahtarı için QR kodu üretir (ZXing), görünür bildirimi olan dinleme hizmeti, 30 saniye alarm ses kanalında siren, yerel ses testi, durdurma ve isteğe bağlı ana ekran simgesi gizleme.
- **QR biçimi:** `SIREN1:<32-hex-key>`; ana uygulama yalnızca bu biçimi kabul eder. İki uygulama aynı kullanıcı anahtarını paylaşır.

## Telefonlarda kurulup çalıştırıldığında

1. Önce eski **Siren Ana** ve **Siren Kullanıcı** uygulamalarını kaldırın: eski elle üretilmiş APK'lar farklı imza taşıdığından üzerine güncelleme yapılamayabilir. Bu işlem önceki eşleşme kodlarını da siler.
2. Yeni `kullanici-debug.apk` dosyasını siren çalacak telefona kurun. Uygulamayı açın, büyük QR kodu görmelisiniz.
3. **BU TELEFONDA SİRENİ TEST ET** düğmesiyle sesin çalıştığını deneyin, **DİNLEMEYİ AÇ** düğmesine basın ve bildirim iznini verin. "Uzaktan Siren etkin" bildirimi görünmelidir.
4. `ana-debug.apk` dosyasını ana telefona kurun. **QR KOD OKUT** düğmesine basın, diğer telefonun QR koduna doğrultun. Google Play Hizmetleri ilk kullanımda tarayıcı modülünü internetten indirmek isteyebilir; Google Play Hizmetleri olmayan telefonlar manuel kodla eşleştirilebilir.
5. Ana telefondan **SİREN ÇALDIR**'a basın. Her iki telefon internete bağlıysa ve Kullanıcı uygulamasındaki dinleme hizmeti açıksa, uzak cihazın ses üretmesi amaçlanır. **DURDUR** komutuyla durdurun.
6. Telefon sessiz olsa bile ses, `USAGE_ALARM` kanalından çalınır. Ancak alarm sesi kapalıysa, Rahatsız Etmeyin alarmları da engelliyorsa veya cihaz üreticisi kısıtlıyorsa ses çıkmayabilir.
7. **ANA EKRAN SİMGESİNİ GİZLE** opsiyoneldir; yalnızca dinleme açık ve bildirimler etkinse çalışır. Uygulama Android Ayarlar > Uygulamalar'da ve etkin hizmet bildiriminde görünür. Dinleme kapanırsa simge geri gelir. Yerel cihaz sahibinin bilgisi/onayıyla kullanın.

## Gerçek APK üretmek

### GitHub Actions (yerel Android Studio gerektirmez)

1. GitHub'da yeni bir depo oluşturun.
2. Bu ZIP arşivinin **içindeki klasör ve dosyaları** (`ana`, `kullanici`, `.github` dahil) repo köküne yükleyin. (ZIP dosyasını tek başına koymak işe yaramaz.)
3. **Actions** sekmesinde **İki Android APK Derle** iş akışını çalıştırın. `main` dalına göndermek de iş akışını başlatır.
4. Başarılı çalışmanın altındaki **Ana-ve-Kullanici-APK** çıktı dosyasından iki gerçek APK'yı indirin: `ana-debug.apk`, `kullanici-debug.apk`.

Not: Bu iş akışı henüz GitHub üzerinde çalıştırılmadı; derleme sırasında hata olursa iş akışı günlükleri incelenmelidir. Debug APK'lar otomatik test amaçlı imzalanır, Play Store yayını için değildir.

### Bilgisayarda Android Studio

Android Studio, Android SDK 35, JDK 17 ve Gradle 8.9 ile projeyi açın. Terminalden `gradle :ana:assembleDebug :kullanici:assembleDebug` komutuyla her iki modülü derleyin. **Bu ZIP Gradle wrapper içermez.**

## Sunucu, güvenlik ve sınırlamalar

- Her iki uygulama `https://ntfy.sh` adlı **üçüncü taraf halka açık** ileti yönlendirme hizmetini kullanır. Kişisel veya hassas veri paylaşmayın. QR içindeki rastgele anahtar, başka kişilerin aynı topic'e erişmesini zorlaştırır; yine de QR'ı gören biri uzaktan komut gönderebilir. Uçtan uca şifreleme veya sunucu taraflı hesap yetkilendirmesi bulunmaz.
- Kullanıcı uygulamasında açıkça başlatılan ve görünür bildirim taşıyan ön plan hizmeti komutları HTTPS üzerinden dinler. Android pil optimizasyonları, internet kesintisi, hizmet sınırları, sunucu kısıtlamaları veya Rahatsız Etmeyin modu nedeniyle **gecikme/kaçırma olabilir; acil durum ya da can güvenliği alarmı yerine kullanılmamalıdır**.
- Ana uygulamasında "komut sunucuya gönderildi" yazması, sirenin cihazda gerçekten çaldığının kanıtı değildir; alıcı onay mekanizması henüz eklenmemiştir.
- Android 14+ için `specialUse` ön plan hizmeti türü ve gerekçesi bildirilmiştir. Bir gün Play Store üzerinden dağıtılacaksa ilgili Play politikaları ayrıca incelenmelidir.
- Kod testi: `bash tests/test_pairing.sh` komutu iki uygulamanın QR formatını Java ile sınar; **Android çalışma testinin yerine geçmez**.

Android Code Scanner: https://developers.google.com/ml-kit/vision/barcode-scanning/code-scanner
Foreground service types: https://developer.android.com/develop/background-work/services/fgs/service-types
ntfy JSON stream: https://docs.ntfy.sh/subscribe/api/
